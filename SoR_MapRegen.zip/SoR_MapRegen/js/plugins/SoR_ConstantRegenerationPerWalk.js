//=============================================================================
// SoR_ConstantRegenerationPerWalk.js
// MIT License (C) 2020 蒼竜 @soryu_rpmaker
// http://opensource.org/licenses/mit-license.php
// ----------------------------------------------------------------------------
// Latest version v0.10 (2020/0X/XX)
//=============================================================================

/*:ja
 * @plugindesc ＜マップ歩数毎定数回復＞ 
 * @author 蒼竜　@soryu_rpmaker
 *
 *
 *  試作版
 *  ステートのメモに
 *  <MapRegen: 10, HP, 5, true>   のように
 *  MapRegen: の後に  歩数、　パラメータ(HP,MP,TPのどれか)、 増減(減らすときはマイナス)、  true（とりあえず今は）
 *　　で記述。
 *  複数タグを列挙すれば、HP/MP/TPの全部を歩数ごとに回復…もできるはず
 *
 *
 *
 *
 *
 */
 
var SoR = SoR || {};
SoR.Parameters = PluginManager.parameters('SoR_ConstRegenPerWalk');
SoR.Param = SoR.Param || {};

 
SoR_CRW_DM_isDatabaseLoaded = DataManager.isDatabaseLoaded;
DataManager.isDatabaseLoaded = function() {
	if(!SoR_CRW_DM_isDatabaseLoaded.call(this)) return false;
	
	if(!SoR.ConstantRegen_isLoaded){//////
      this.getStateWalkTags($dataStates);
	  SoR.ConstantRegen_isLoaded = true;
	}
    return true;
};

 
DataManager.getStateWalkTags = function(States) {
	for (var i = 1; i < States.length; i++) {
    var state_obj = States[i];
	state_obj.mapRegen = [];
	
	//mapswitch tag	
 	var tag = /<(?:MapRegen):[ ]*(\d+),[ ]*(.*),[ ]*([+,-]?\d+),[ ]*(.*)>/i;
	var notes = state_obj.note.split(/[\r\n]+/);
		for (var n = 0; n < notes.length; n++) {
			  var line = notes[n];
			 // console.log(line)
			  if (line.match(tag)) {
			     var mapReg = {
					stepsForRegen: parseInt(RegExp.$1),
					stateParam: String(RegExp.$2),
					RegenValue: parseInt(RegExp.$3),
					IsCompatible: Boolean(RegExp.$4)
				};
				
				//console.log(mapReg)
				state_obj.mapRegen.push(mapReg);
				
	  	     }
		}
//	console.log(state_obj.mapRegen);
    }
};
	
	
	

var SoR_GA_CRW_turnEndOnMap = Game_Actor.prototype.turnEndOnMap;
Game_Actor.prototype.turnEndOnMap = function() {
	
//	if(this._states.length>0)console.log(this._states[0]);
	
	SoR_GA_CRW_turnEndOnMap.call(this);
	
	this.Regenaration_onMap();
};


Game_Actor.prototype.Regenaration_onMap = function() {

    for(var i=0; i < this._states.length; i++){
		var state_id = this._states[i];
		if($dataStates[state_id].mapRegen && $dataStates[state_id].mapRegen.length > 0){
			for(var j=0; j < $dataStates[state_id].mapRegen.length; j++){
				var mapReg_data = $dataStates[state_id].mapRegen[j];
				if($gameParty.steps() % mapReg_data.stepsForRegen == 0){
					switch(mapReg_data.stateParam){
						case "HP":
						this.regenerateHp_onMap(mapReg_data.RegenValue);
						if(mapReg_data.RegenValue < 0) this.performMapDamage();
						break;
						
						case "MP":
						this.regenerateHp_onMap(mapReg_data.RegenValue);
						break;
						
						case "TP":
						this.regenerateHp_onMap(mapReg_data.RegenValue);
						break;
						
					}					
				}
				
			}
		}
		
	}

}


Game_Battler.prototype.regenerateHp_onMap = function(val) {
    val = Math.max(val, -this.maxSlipDamage());
	console.log(val)
    if (val !== 0) { this.gainHp(val); }
};

Game_Battler.prototype.regenerateMp_onMap = function(val) {
    if (val !== 0){ this.gainMp(val); }
};

Game_Battler.prototype.regenerateTp_onMap = function(val) {
    if (val !== 0){ this.gainSilentTp(val); }
};




/*

(function () {
  'use strict';
    var SoR_Game_Map_setup = Game_Map.prototype.setup;
    Game_Map.prototype.setup = function(mapId) {
        SoR_Game_Map_setup.call(this, mapId);
	    $dataMap.switchbgm_flagID = [];
		$dataMap.switched_bgm = []; // switch bgm candidate array
        setMapBGMtags();
    };


    function getStateWalkTags(){
	//mapswitch tag	
 	var tag = /<(?:mapswitch):[ ]*(.*),[ ]*(.*),[ ]*(.*),[ ]*(.*),[ ]*(.*),[ ]*(.*)>/i;
	var notes = $dataMap.note.split(/[\r\n]+/);
		for (var n = 0; n < notes.length; n++) {
			  var line = notes[n];
			  if (line.match(tag)) {
				 var ID = parseInt(RegExp.$1);
			     var switchbgm = {
					name: String(RegExp.$2),
					volume: parseInt(RegExp.$3),
					pitch: parseInt(RegExp.$4),
					pan: parseInt(RegExp.$5),
					pos: parseInt(RegExp.$6)
				};
				
				$dataMap.switchbgm_flagID.push(ID);
				$dataMap.switched_bgm.push(switchbgm);
	  	     }
		}
    };
})();



*/











/*
 
Game_Actor.prototype.stepsForTurn = function() {
    return 20;
};

var SoR_GA_CRW_turnEndOnMap = Game_Actor.prototype.turnEndOnMap;
Game_Actor.prototype.turnEndOnMap = function() {
	
	SoR_GA_CRW_turnEndOnMap.call();
	
	/*
    if ($gameParty.steps() % this.stepsForTurn() === 0) {
        this.onTurnEnd();
        if (this.result().hpDamage > 0) {
            this.performMapDamage();
        }
    }
	*/
	
	